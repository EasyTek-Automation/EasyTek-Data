# src/components/sidebars/__init__.py

"""
Módulo de conteúdos para a sidebar da aplicação.
Cada página pode ter seu próprio conjunto de itens na sidebar.
"""

from src.components.sidebars.dashboard_sidebar import create_dashboard_sidebar_content
from src.components.sidebars.states_sidebar import create_states_sidebar_content
from src.components.sidebars.superv_sidebar import create_superv_sidebar_content
from src.components.sidebars.default_sidebar import create_default_sidebar_content

__all__ = [
    'create_dashboard_sidebar_content',
    'create_states_sidebar_content',
    'create_superv_sidebar_content',
    'create_default_sidebar_content'
]
